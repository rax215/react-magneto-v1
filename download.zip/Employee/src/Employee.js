import {useState} from 'react';
    import { Bar } from 'react-chartjs-2';
import { Grid, Paper, TextField, FormLabel, RadioGroup, FormControlLabel, Radio, Select, MenuItem, InputLabel, FormControl, Checkbox, FormGroup, Container } from '@material-ui/core'
   let componentOptions = {"genderOptions":["Male","Female","Other"],"maritalStatusOptions":["Married","Unmarried","Other"],"languagesOptions":["English","Hindi","Spanish","Chinese","Other"],"ownPolicyOptions":["Yes","No"]} 
   let BarChartData = JSON.parse("{\"labels\":[\"January\", \"February\", \"March\", \"April\", \"May\", \"June\"],\"datasets\":[{\"label\":\"# of Policies Renewed\",\"data\":[12,19,3,5,2,3],\"backgroundColor\":[\"rgba(255, 99, 132, 0.2)\",\"rgba(54, 162, 235, 0.2)\",\"rgba(255, 206, 86, 0.2)\",\"rgba(75, 192, 192, 0.2)\",\"rgba(153, 102, 255, 0.2)\",\"rgba(255, 159, 64, 0.2)\"],\"borderColor\":[\"rgba(255, 99, 132, 1)\",\"rgba(54, 162, 235, 1)\",\"rgba(255, 206, 86, 1)\",\"rgba(75, 192, 192, 1)\",\"rgba(153, 102, 255, 1)\",\"rgba(255, 159, 64, 1)\"],\"borderWidth\":1}]}")
      let BarChartOptions = JSON.parse("{\"maintainAspectRatio\": false, \"scales\":{\"yAxes\":[{\"ticks\":{\"beginAtZero\":true}}]}}")
        

 const Employee = () => {
  let initialValues = {"gender":"","maritalStatus":"","languages":"","ownPolicy":""}
  const [values, setValues] = useState({initialValues});
  return (
    <div>            
      

<Grid className="wrapper" variant="outlined">       
        <TextField id="custName" label="Customer First Name: " className="formlabel" variant="outlined" />
    </Grid>
<Grid className="wrapper" variant="outlined">       
        <TextField id="custLastName" label="Customer Last Name: " className="formlabel" variant="outlined" />
    </Grid>

   <Paper variant="outlined" className="wrapper">
            <Grid item xs>
                   <FormLabel className="formlabel" required="undefined">Gender:</FormLabel>
    
                <RadioGroup aria-label="gender" name="Gender:" >
                    {componentOptions.genderOptions.map((item) => (
                        <FormControlLabel value={item} control={<Radio />} label={item} /> ))}
                </RadioGroup>
            </Grid>
        </Paper>

    


   <Paper variant="outlined" className="wrapper">
            <FormControl style={{minWidth:135}}> 
                <InputLabel id="maritalStatusLabel" required={true}> Marital Status </InputLabel>
                <Select id="maritalStatus" value={values.maritalStatus}>
                    <MenuItem value="">
                        <em>None</em>
                    </MenuItem>    
                    {componentOptions.maritalStatusOptions.map(item =>
                        <MenuItem key={item} value={item}>{item}</MenuItem>        
                    )}
                </Select>
            </FormControl>
        </Paper>
    



<Paper variant="outlined" className="wrapper">
            <Grid item xs>
               <FormLabel className="formlabel" required="true">Languages</FormLabel>
                       
                    <FormGroup>
                        {componentOptions.languagesOptions.map((item) => (
                            <FormControlLabel control={<Checkbox name={item} />} label={item} />
                            ))}
                    </FormGroup>
            </Grid>  
        </Paper>
    


   <Paper variant="outlined" className="wrapper">
            <Grid item xs>
                   <FormLabel className="formlabel" required="undefined">Do you own any policy with us?</FormLabel>
    
                <RadioGroup aria-label="ownPolicy" name="Do you own any policy with us?" >
                    {componentOptions.ownPolicyOptions.map((item) => (
                        <FormControlLabel value={item} control={<Radio />} label={item} /> ))}
                </RadioGroup>
            </Grid>
        </Paper>

    


<div style={{width:500, height:300 }}><Bar data={BarChartData}  options={BarChartOptions}/></div>
    </div>
  )
}
export default Employee