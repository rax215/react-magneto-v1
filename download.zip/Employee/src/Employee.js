import { Bar, Pie } from 'react-chartjs-2';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from '@material-ui/pickers';

    import DateFnsUtils from "@date-io/date-fns";
import {useState} from 'react';
    import { Grid, Paper, Container, TextField, FormLabel, RadioGroup, FormControlLabel, Radio, Select, MenuItem, InputLabel, FormControl, Checkbox, FormGroup, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,  } from '@material-ui/core';
    import './App.css';
   let componentOptions = {"genderOptions":["Male","Female","Other"],"maritalStatusOptions":["Married","Unmarried","Other"],"languagesOptions":["English","Hindi","Spanish","Chinese","Other"],"ownPolicyOptions":["Yes","No"]} 
   let BarChartData = JSON.parse("{\"labels\":[\"January\", \"February\", \"March\", \"April\", \"May\", \"June\"],\"datasets\":[{\"label\":\"# of Policies Renewed\",\"data\":[12,19,3,5,2,3],\"backgroundColor\":[\"rgba(255, 99, 132, 0.2)\",\"rgba(54, 162, 235, 0.2)\",\"rgba(255, 206, 86, 0.2)\",\"rgba(75, 192, 192, 0.2)\",\"rgba(153, 102, 255, 0.2)\",\"rgba(255, 159, 64, 0.2)\"],\"borderColor\":[\"rgba(255, 99, 132, 1)\",\"rgba(54, 162, 235, 1)\",\"rgba(255, 206, 86, 1)\",\"rgba(75, 192, 192, 1)\",\"rgba(153, 102, 255, 1)\",\"rgba(255, 159, 64, 1)\"],\"borderWidth\":1}]}")
      let BarChartOptions = JSON.parse("{\"maintainAspectRatio\": false, \"scales\":{\"yAxes\":[{\"ticks\":{\"beginAtZero\":true}}]}}")
       let PieChartData = JSON.parse("{\"labels\":[\"January\", \"February\", \"March\", \"April\", \"May\", \"June\"],\"datasets\":[{\"label\":\"# of Policies Renewed\",\"data\":[12,19,3,5,2,3],\"backgroundColor\":[\"rgba(255, 99, 132, 0.2)\",\"rgba(54, 162, 235, 0.2)\",\"rgba(255, 206, 86, 0.2)\",\"rgba(75, 192, 192, 0.2)\",\"rgba(153, 102, 255, 0.2)\",\"rgba(255, 159, 64, 0.2)\"],\"borderColor\":[\"rgba(255, 99, 132, 1)\",\"rgba(54, 162, 235, 1)\",\"rgba(255, 206, 86, 1)\",\"rgba(75, 192, 192, 1)\",\"rgba(153, 102, 255, 1)\",\"rgba(255, 159, 64, 1)\"],\"borderWidth\":1}]}")
      let PieChartOptions = JSON.parse("{\"maintainAspectRatio\": false, \"scales\":{\"yAxes\":[{\"ticks\":{\"beginAtZero\":true}}]}}")
       
   let employeeTableColumns = JSON.parse("[{ \"field\": \"id\", \"label\": \"ID\" }, { \"field\": \"firstName\", \"label\": \"First name\" }, { \"field\": \"lastName\", \"label\": \"Last name\" }, { \"field\": \"age\", \"label\": \"Age\", \"type\": \"number\" }]")
      let employeeTableRows = JSON.parse("[{ \"id\": 1, \"lastName\": \"Snow\", \"firstName\": \"Jon\", \"age\": 35 }, { \"id\": 2, \"lastName\": \"Lannister\", \"firstName\": \"Cersei\", \"age\": 42 }, { \"id\": 3, \"lastName\": \"Lannister\", \"firstName\": \"Jaime\", \"age\": 45 }, { \"id\": 4, \"lastName\": \"Stark\", \"firstName\": \"Arya\", \"age\": 16 }, { \"id\": 5, \"lastName\": \"Targaryen\", \"firstName\": \"Daenerys\", \"age\": 30 }, { \"id\": 6, \"lastName\": \"Melisandre\", \"firstName\": null, \"age\": 50 }, { \"id\": 7, \"lastName\": \"Clifford\", \"firstName\": \"Ferrara\", \"age\": 44 }, { \"id\": 8, \"lastName\": \"Frances\", \"firstName\": \"Rossini\", \"age\": 36 }, { \"id\": 9, \"lastName\": \"Roxie\", \"firstName\": \"Harvey\", \"age\": 65 }]")
         

 const Employee = () => {
  let initialValues = {"gender":"","maritalStatus":"","languages":"","ownPolicy":""}
  const [values, setValues] = useState({initialValues});
  return (
    <div> 
      <Container maxWidth="lg"> 
      <Paper variant="outlined"> 
      <Grid container className="wrapper"> 
      <Grid container item lg={11} spacing={0}
      direction="column"
      alignItems="center"
      justify="center">
      <h1>Customer Info  </h1>  
      </Grid>  
        


<Grid item lg={4} variant="outlined" className="wrapper">       
        <TextField id="custName" label="Customer First Name: " className="formlabel" variant="outlined" />
    </Grid>
<Grid item lg={4} variant="outlined" className="wrapper">       
        <TextField id="middle name" label="Customer middle  Name: " className="formlabel" variant="outlined" />
    </Grid>
<Grid item lg={4} variant="outlined" className="wrapper">       
        <TextField id="custLastName" label="Customer Last Name: " className="formlabel" variant="outlined" />
    </Grid>

 <Grid item lg={4} className="wrapper">
                   <FormLabel className="formlabel" required="false">Gender:</FormLabel>
    
                <RadioGroup aria-label="gender" name="Gender:" >
                    {componentOptions.genderOptions.map((item) => (
                        <FormControlLabel value={item} control={<Radio />} label={item} /> ))}
                </RadioGroup>
            </Grid>
    


 <Grid item lg={4} className="wrapper">
                <InputLabel id="maritalStatusLabel" required={true}> Marital Status </InputLabel>
                <Select id="maritalStatus" value={values.maritalStatus}>
                    <MenuItem value="">
                        <em>None</em>
                    </MenuItem>    
                    {componentOptions.maritalStatusOptions.map(item =>
                        <MenuItem key={item} value={item}>{item}</MenuItem>        
                    )}
                </Select>
           </Grid>
    



<Grid item lg={4} className="wrapper">
               <FormLabel className="formlabel" required="true">Languages</FormLabel>
                       
                    <FormGroup>
                        {componentOptions.languagesOptions.map((item) => (
                            <FormControlLabel control={<Checkbox name={item} />} label={item} />
                            ))}
                    </FormGroup>
            </Grid>
    


 <Grid item lg={4} className="wrapper">
                   <FormLabel className="formlabel" required="false">Do you own any policy with us?</FormLabel>
    
                <RadioGroup aria-label="ownPolicy" name="Do you own any policy with us?" >
                    {componentOptions.ownPolicyOptions.map((item) => (
                        <FormControlLabel value={item} control={<Radio />} label={item} /> ))}
                </RadioGroup>
            </Grid>
    


<div style={{width:500, height:300 }}><Bar data={BarChartData}  options={BarChartOptions}/></div>
<TableContainer style={{maxHeight: 440}}>
  <Table stickyHeader >
    <TableHead>
      <TableRow>
      {employeeTableColumns.map((column) => (
            <TableCell key={column.field}>
              {column.label}
            </TableCell>
          ))}
      </TableRow>
    </TableHead>
    <TableBody>
    {employeeTableRows.map((row) => {
          return (
            <TableRow key={row.id}>
              {employeeTableColumns.map((column) => {
                const value = row[column.field];
                return (
                  <TableCell key={column.field} >
                    {value}
                  </TableCell>
                );
              })}
            </TableRow>
          );
        })}
    </TableBody>
  </Table>
</TableContainer> 





<div style={{width:500, height:300 }}><Pie data={PieChartData} options={PieChartOptions}/></div>

<Grid item lg={4} className="wrapper">
            <form noValidate>
                <TextField
                    id="date"
                    label="Date of Birth:"
                    type="date"
                    defaultValue="MM/dd/yyyy"
                    InputLabelProps={{
                    shrink: true,
                    }}
                />
            </form>
          {/*  This new component does not work when change the date value as we required introduce the onChange function
            <MuiPickersUtilsProvider utils={DateFnsUtils}> 
                <KeyboardDatePicker
                    variant="inline"
                    format="MM/dd/yyyy"
                    margin="normal"
                    id="date"
                    label="Date of Birth:"
                    KeyboardButtonProps={{
                        'aria-label': 'change date'
                    }}
                />
                </MuiPickersUtilsProvider>     */  }                
        </Grid>
    

      </Grid>
      </Paper>
      </Container>
    </div>
  )
}
export default Employee